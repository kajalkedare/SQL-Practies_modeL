CREATE TABLE LOCATION (
  Location_ID INT PRIMARY KEY,
  City VARCHAR(50)
);

INSERT INTO LOCATION (Location_ID, City)
VALUES (122, 'New York'),
       (123, 'Dallas'),
       (124, 'Chicago'),
       (167, 'Boston');


  CREATE TABLE DEPARTMENT (
  Department_Id INT PRIMARY KEY,
  Name VARCHAR(50),
  Location_Id INT,
  FOREIGN KEY (Location_Id) REFERENCES LOCATION(Location_ID)
);


INSERT INTO DEPARTMENT (Department_Id, Name, Location_Id)
VALUES (10, 'Accounting', 122),
       (20, 'Sales', 124),
       (30, 'Research', 123),
       (40, 'Operations', 167);

	   CREATE TABLE JOB (
  Job_ID INT PRIMARY KEY,
  Designation VARCHAR(50)
);

CREATE TABLE JOB
(JOB_ID INT PRIMARY KEY,
DESIGNATION VARCHAR(20))

INSERT  INTO JOB VALUES
(667, 'CLERK'),
(668,'STAFF'),
(669,'ANALYST'),
(670,'SALES_PERSON'),
(671,'MANAGER'),
(672, 'PRESIDENT')


CREATE TABLE EMPLOYEE
(EMPLOYEE_ID INT,
LAST_NAME VARCHAR(20),
FIRST_NAME VARCHAR(20),
MIDDLE_NAME CHAR(1),
JOB_ID INT FOREIGN KEY
REFERENCES JOB(JOB_ID),
MANAGER_ID INT,
HIRE_DATE DATE,
SALARY INT,
COMM INT,
DEPARTMENT_ID  INT FOREIGN KEY
REFERENCES DEPARTMENT(DEPARTMENT_ID))

INSERT INTO EMPLOYEE VALUES
(7369,'SMITH','JOHN','Q',667,7902,'17-DEC-84',800,NULL,20),
(7499,'ALLEN','KEVIN','J',670,7698,'20-FEB-84',1600,300,30),
(7505,'DOYLE','JEAN','K',671,7839,'04-APR-85',2850,NULl,30),
(7506,'DENNIS','LYNN','S',671,7839,'15-MAY-85',2750,NULL,30),
(7507,'BAKER','LESLIE','D',671,7839,'10-JUN-85',2200,NULL,40),
(7521,'WARK','CYNTHIA','D',670,7698,'22-FEB-85',1250,500,30)

--Q1List all the employee details.
SELECT * FROM EMPLOYEE

--Q2 List all the department details
SELECT * FROM DEPARTMENT

--Q3List all job details
SELECT * FROM JOB

--Q4 List all the locations
SELECT * FROM LOCATION

--Q5 List out the First Name, Last Name, Salary, Commission for all Employees
 SELECT FIRST_NAME,LAST_NAME ,SALARY,COMM FROM EMPLOYEE

--Q6  List out the Employee ID, Last Name, Department ID for all employees and
--alias
--Employee ID as "ID of the Employee", Last Name as "Name of the
--Employee", Department ID as "Dep_id"

SELECT (EMPLOYEE_ID )AS ID_OF_THE_EMPLOYEE ,
(LAST_NAME ) AS NAME_OF_THE_EMPLOYEE ,(DEPARTMENT_ID ) AS DEP_ID FROM EMPLOYEE
GO

--Q7  List out the annual salary of the employees with their names only
SELECT CONCAT(FIRST_NAME, LAST_Name) as _Name ,salary from employee

SELECT * FROM EMPLOYEE
GO



--WHERE Condition:
--Q1. List the details about "Smith".
SELECT * FROM EMPLOYEE WHERE LAST_NAME ='SMITH'

--Q2. List out the employees who are working in department 20.
SELECT * FROM EMPLOYEE WHERE DEPARTMENT_ID =20

--Q3. List out the employees who are earning salary between 2000 and 3000.
SELECT * FROM EMPLOYEE WHERE SALARY BETWEEN 2000 AND 3000


--Q4. List out the employees who are working in department 10 or 20.
SELECT * FROM EMPLOYEE WHERE DEPARTMENT_ID IN(10,20)


--Q5. Find out the employees who are not working in department 10 or 30.
SELECT * FROM EMPLOYEE WHERE DEPARTMENT_ID IN(10,30)


--Q6. List out the employees whose name starts with 'L'
SELECT * FROM EMPLOYEE WHERE FIRST_NAME LIKE'L%';

--Q7. List out the employees whose name starts with 'L' and ends with 'E'.
SELECT * FROM EMPLOYEE WHERE  FIRST_NAME  LIKE 'L%' 
SELECT * FROM EMPLOYEE WHERE  FIRST_NAME  LIKE '%E' 


--Q8. List out the employees whose name length is 4 and start with 'J'.
SELECT  SUBSTRING(FIRST_NAME ,1,4) AS DIGIT_4_NAME FROM EMPLOYEE
WHERE  FIRST_NAME  LIKE  'J%' 

--Q9. List out the employees who are working in department 30 and draw the
--salaries more than 2500.

SELECT * FROM EMPLOYEE WHERE DEPARTMENT_ID =30 AND SALARY > 2500

--Q10. List out the employees who are not receiving commission
SELECT * FROM EMPLOYEE WHERE COMM = NULL

SELECT * FROM EMPLOYEE
GO


--0RDER BY Clause:
--Q1. List out the Employee ID and Last Name in ascending order based on the
--Employee ID.
 SELECT EMPLOYEE_ID ,LAST_NAME  FROM  EMPLOYEE 
 ORDER BY EMPLOYEE_ID 


--Q2. List out the Employee ID and Name in descending order based on salary.
SELECT EMPLOYEE_ID,FIRST_NAME ,SALARY FROM EMPLOYEE 
ORDER BY SALARY DESC

--Q3. List out the employee details according to their Last Name in ascending-order.
SELECT * FROM EMPLOYEE 
ORDER BY LAST_NAME ASC

--Q4. List out the employee details according to their Last Name in ascending
--order and then Department ID in descending order.
SELECT * FROM EMPLOYEE 
ORDER BY  DEPARTMENT_ID DESC, LAST_NAME ASC 
GO



--GROUP BY and HAVING Clause:
--Q1. List out the department wise maximum salary, minimum salary and
--average salary of the employees.
SELECT * FROM EMPLOYEE

SELECT DEPARTMENT_ID  ,MAX(SALARY)  AS MAXIMUM_SAL  ,
MIN(SALARY) AS MINIMUM_SAL ,
AVG(SALARY) AS AVERAGE_SAL  FROM EMPLOYEE
GROUP BY DEPARTMENT_ID 


--Q2. List out the job wise maximum salary, minimum salary and average
--salary of the employees.
SELECT JOB_ID  ,MAX(SALARY)  AS MAXIMUM_SAL  ,
MIN(SALARY) AS MINIMUM_SAL ,
AVG(SALARY) AS AVERAGE_SAL  FROM EMPLOYEE
GROUP BY JOB_ID 


--Q3. List out the number of employees who joined each month in ascending order.
SELECT * FROM EMPLOYEE

SELECT *   FROM EMPLOYEE
--GROUP BY HIRE_DATE 
ORDER BY HIRE_DATE 



--Q4. List out the number of employees for each month and year in
--ascending order based on the year and month.
 SELECT HIRE_DATE ,
 DATEPART(MONTH,[HIRE_DATE])AS MONTHS ,DATEPART(YEAR,[HIRE_DATE])AS HIRED_YEAR FROM EMPLOYEE
 ORDER BY HIRED_YEAR ASC


--Q5. List out the Department ID having at least four employees.
SELECT DEPARTMENT_ID FROM EMPLOYEE
WHERE DEPARTMENT_ID >4
GROUP BY DEPARTMENT_ID 



--Q6. How many employees joined in February month.
SELECT * FROM EMPLOYEE 
WHERE  MONTH(HIRE_DATE) = 2



--Q7. How many employees joined in May or June month.
SELECT * FROM EMPLOYEE
WHERE MONTH(HIRE_DATE) = 5   OR MONTH(HIRE_DATE) = 6


--Q8. How many employees joined in 1985?
SELECT * FROM EMPLOYEE 
WHERE YEAR(HIRE_DATE) = 1985

--Q9. How many employees joined each month in 1985?

SELECT * ,HIRE_DATE,MONTH(HIRE_DATE) AS MONTH_JOINING FROM  EMPLOYEE
WHERE YEAR(HIRE_DATE) = 1985 


--Q10. How many employees were joined in April 1985?

SELECT * FROM  EMPLOYEE
WHERE YEAR(HIRE_DATE) = 1985 AND
MONTH(HIRE_DATE)  = 4


--Q11. Which is the Department ID having greater than or equal to 3 employees
--joining in ApRIL 1985

SELECT DEPARTMENT_ID FROM  EMPLOYEE
WHERE  DEPARTMENT_ID >= 3   AND  YEAR(HIRE_DATE) = 1985 AND
MONTH(HIRE_DATE)  = 4
GO


--Joins:
SELECT *  FROM EMPLOYEE
SELECT * FROM DEPARTMENT
SELECT * FROM JOB
SELECT * FROM LOCATION

--Q1. List out employees with their department names.

SELECT * FROM EMPLOYEE E INNER JOIN DEPARTMENT D ON E.DEPARTMENT_ID=D.DEPARTMENT_ID


--Q2. Display employees with their designations.
SELECT * FROM EMPLOYEE E LEFT JOIN JOB J ON E.JOB_ID=J.JOB_ID 


--Q3. Display the employees with their department names and city.

SELECT * FROM EMPLOYEE E LEFT JOIN DEPARTMENT D ON E.DEPARTMENT_ID=D.DEPARTMENT_ID
LEFT JOIN LOCATION L ON L.LOCATION_ID = D.LOCATION_ID

SELECT D.NAME,L.CITY FROM EMPLOYEE E LEFT JOIN DEPARTMENT D ON E.DEPARTMENT_ID=D.DEPARTMENT_ID
LEFT JOIN LOCATION L ON L.LOCATION_ID = D.LOCATION_ID


--Q4. How many employees are working in different departments? Display with
--department names.
SELECT E.EMPLOYEE_ID , D.Name FROM EMPLOYEE E RIGHT JOIN DEPARTMENT D ON E.DEPARTMENT_ID=D.DEPARTMENT_ID


--Q5. How many employees are working in the sales department?
SELECT * , D.Name FROM EMPLOYEE E RIGHT JOIN DEPARTMENT D ON E.DEPARTMENT_ID=D.DEPARTMENT_ID
WHERE D.Name='SALES'

--Q6. Which is the department having greater than or equal to 3
--employees and display the department names in
--ascending order.
SELECT E.EMPLOYEE_ID,E.DEPARTMENT_ID, D.Name FROM EMPLOYEE E INNER JOIN DEPARTMENT D ON D.DEPARTMENT_ID=E.DEPARTMENT_ID
WHERE E.DEPARTMENT_ID > = 3
ORDER BY D.Name ASC

SELECT * FROM LOCATION
SELECT * FROM DEPARTMENT


--Q7. How many employees are working in 'Dallas'?
SELECT * FROM DEPARTMENT D  LEFT JOIN LOCATION L ON L.LOCATION_ID = D.LOCATION_ID
WHERE L.CITY = 'DALLAS'

--Q8. Display all employees in sales or operation departments.
SELECT * , D.Name FROM EMPLOYEE E INNER  JOIN DEPARTMENT D ON E.DEPARTMENT_ID=D.DEPARTMENT_ID
WHERE D.Name  IN ('SALES' ,'OPERATIONS')
GO



--CONDITIONAL STATEMENT
--Q1. Display the employee details with salary grades. Use conditional statement to
--create a grade column.
SELECT * , (SALARY)AS SALARY_GRADE FROM EMPLOYEE 


--Q2. List out the number of employees grade wise. Use conditional statement to
--create a grade column.
SELECT  (SALARY)AS SALARY_GRADE , COUNT(EMPLOYEE_ID)  AS NO_OF_EMPLOYEE FROM EMPLOYEE 
GROUP BY SALARY



--Q3. Display the employee salary grades and the number of employees between
--2000 to 5000 range of salary
SELECT   COUNT(EMPLOYEE_ID)AS NUMBER_OF_EMP , (SALARY)AS SALARY_GRADE FROM EMPLOYEE 
WHERE  SALARY BETWEEN 2000 AND 5000
GROUP BY  EMPLOYEE_ID ,SALARY
















