use SMALL

SELECT * FROM Jomato$
--Q1Create a user-defined functions to stuff the Chicken into �Quick Bites�. Eg: �Quick
--Chicken Bites

CREATE OR ALTER FUNCTION  fn_RESTODATA
(@menu varchar(40))
	
RETURNS table
AS
RETURN
SELECT RESTAURANTTYPE ,STUFF('QUICK BITES ',6,17,@menu) AS NEW_NAME_STUFFE_COLMN FROM JOMATO$
   WHERE RestaurantType ='QUICK BITES';
   
GO

select * from fn_RESTODATA('chicken')
go

--Q2Use the function to display the restaurant name and cuisine type which has the
--maximum number of rating

SELECT RestaurantName , CuisinesType  ,MAX(NO#OF#RATING) AS  MAX_NO_OF_RATING FROM Jomato$
GROUP BY RestaurantName,CuisinesType
order by MAX_NO_OF_RATING desc
go





--Q3
SELECT * FROM Jomato$

alter table jomato$  add  rating_statues int;

 select restaurantName , rating_statues
 (select * ,

 case( Rating <= 4  then   'EXCELLENT',
	
		Rating <= 4    THEN  print 'GOOD',
		Rating  < =  3 THEN  print 'AVERAGE',
		
		Rating < 3 THEN  print  'BAD',
		else end)t
		)
		from  jomato$


--Q4Find the Ceil, floor and absolute values of the rating column and display the current
--date and separately display the year, month_name and day.

 alter table jomato$ add CurrentDate date ;

 UPDATE Jomato$ SET CURRENTDATE=GETDATE()




SELECT CURRENTDATE ,   
	DATEPART (DAY,[CURRENTDATE])AS ORDER_DAY,
    DATEPART(MONTH,[CURRENTDATE]) AS ORDER_MONTH ,
  DATEPART( YEAR,[CURRENTDATE])AS ORDER_YEAR , 
  FLOOR(RATING) FLOOR_RATING_COL  ,
  CEILING(RATING) CEILING_RATING_COL,
   ABS(RATING) ABSOLUTE_RATING_COL FROM Jomato$


--Q5 Display the restaurant type and total average cost using rolluP
SELECT RestaurantName ,SUM(AVERAGECOST) AS AVRAGE_COST_OF_ORDER FROM Jomato$
GROUP BY RestaurantName
WITH ROLLUP
		 
		 SELECT * FROM Jomato$

		
	

		




