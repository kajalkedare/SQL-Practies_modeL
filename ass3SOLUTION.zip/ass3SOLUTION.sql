
--SQL Mandatory Assignment 3

--Dataset: Jomato

--Tasks to be performed:
use SMALL
select * from Jomato$

--1. Create a stored procedure to display the restaurant name, type and cuisine where the
--table booking is not zero.

CREATE  OR ALTER PROCEDURE sp_disply6(@tb int)

as
begin 
if @tb <>0
	SELECT RESTAURANTNAME,RESTAURANTTYPE,CuisinesType FROM Jomato$


	else 
	print ('no details found')
end
EXEC sp_disply6 657
GO

--2. Create a transaction and update the cuisine type �Cafe� to �Cafeteria�. Check the result
--and rollback it.


CREATE OR ALTER procedure sp_joma
as
	 BEGIN TRY
	 SET  TRANSACTION ISOLATION LEVEL READ COMMITTED
	 begin transaction
	 update Jomato$ 
	 SET CuisinesType = 'cafeteria'
	 FROM Jomato$ AS JOMA
	 WHERE CuisinesType=  'cafe'

	 --2nd updation
	  update Jomato$ 
	 SET CuisinesType = 'order'
	 FROM Jomato$ AS JOMA
	 WHERE CuisinesType=  ' 345 '

	 COMMIT TRANSACTION
		SELECT 'COMMITTRABSACTION'
	 END TRY
	 BEGIN CATCH
	 ROLLBACK TRANSACTION
	 SELECT'ROLLBACKTRANSACTION'
	 END CATCH

EXEC sp_joma
select @@trancount
	 
go








--3. Generate a row number column and find the top 5 areas with the highest rating of
--restaurants.

select * from Jomato$
alter table jomato$  add  row_number int 
select top 5   Area , max(rating)as row_number from Jomato$ 
where Rating > 4.5
group by Area,Rating

--4. Use the while loop to display the 1 to 50.
create procedure sp_order5(@a int)
as
begin 
 
		while( @a >0   and   @a< =50)
	begin
		select top 50 *  from Jomato$
	end
		print 'no record'
end

exec sp_order5 8
go

--5. Write a query to Create a Top rating view to store the generated top 5 highest rating of
--restaurants.
create or alter view vw_toprating
as
	select  top 5 * ,rank()over(order by rating desc) as resto_rating  from Jomato$
	
	
select * from vw_toprating



 
--6. Create a trigger that give an message whenever a new record is inserted.
create trigger TR_022 on jomato$ for insert
as 
BEGIN
select * from  INSERTED
END

	INSERT INTO  Jomato$(ORDERID, RestaurantType,RestaurantName ,Rating ,No#of#Rating  ,AverageCost,OnlineOrder,TableBooking,CuisinesType,area,LocalAddress,
	 [Delivery time]   , rating_statues,CurrentDate,row_number)values(90099,'KING CAFFEE','CAFE',4.2,67,565,'YES','no','HUSSANFGYGY','CAFE,BREVRAGES','HN',68,'GFCG',getdate()
	 ,5)
		
		SP_HELPTEXT TR_022
GO

	
		
		
		
		SELECT * FROM Jomato$